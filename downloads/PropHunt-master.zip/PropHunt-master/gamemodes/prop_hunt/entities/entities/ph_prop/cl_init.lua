// Include needed files
include("shared.lua")


// Called every frame?
function ENT:Draw()
	self.Entity:DrawModel()
end 