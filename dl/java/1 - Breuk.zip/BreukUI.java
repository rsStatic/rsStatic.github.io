public class BreukUI{
	
	public static void main(String[] args){
		Breuk eenHalf= new Breuk(1,2);
		System.out.println(eenHalf.toString());
		Breuk ookEenHalf= new Breuk(2,3);
		System.out.println(ookEenHalf.toString());
		if (eenHalf.heeftZelfdeWaarde(ookEenHalf)){
			System.out.println("Deze breuken hebben dezelfde waarde");
		}
		else{
			System.out.println("Deze breuken hebben nietdezelfde waarde");
			}
		System.exit(0);
	}
}