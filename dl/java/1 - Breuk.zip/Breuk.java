public class Breuk{
	private int teller, noemer = 1;

	public Breuk(int teller, int noemer){
		this.setTeller(teller);
		this.setNoemer(noemer);
	}

	public int getTeller(){
		return this.teller;
	}

	public int getNoemer(){
		return this.noemer;
	}

	private void setTeller(int teller){
		this.teller= teller;
	}

	private void setNoemer(int noemer){
		if (noemer!=0){
			this.noemer= noemer;
		}
	}

	public boolean heeftZelfdeWaarde(Breuk b){
		return (((double)this.teller/this.noemer) == ((double)b.getTeller()/b.getNoemer()));
	}

	public String toString(){
		return this.teller + "/" + this.noemer;
	}
}